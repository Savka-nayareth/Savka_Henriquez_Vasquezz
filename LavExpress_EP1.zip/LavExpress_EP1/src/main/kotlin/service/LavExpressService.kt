package service

import exception.MaquinaNoEncontradaException
import exception.OperacionSlotException
import exception.SinCapacidadException
import exception.TarifaInvalidaException
import kotlinx.coroutines.delay
import model.*
import util.Validador
import java.text.DecimalFormat

class LavExpressService {
    val nombre = "LavExpress"
    val capacidad = 10

    private val slots = MutableList(capacidad) { indice -> Slot(indice + 1) }
    private val historial = mutableListOf<Atencion>()
    private val recaudacionPorTipo = TipoMaquina.entries.associateWith { 0.0 }.toMutableMap()

    private var siguienteTicket = 1
    var recaudacionTotal: Double = 0.0
        private set

    suspend fun registrarEntrada(maquina: Maquina) {
        val slot = slots.firstOrNull { estadoPermiteEntrada(it.estado) }
            ?: throw SinCapacidadException()

        // El slot queda temporalmente en procesamiento mientras responde el sensor.
        slot.estado = EstadoSlot.EnCicloFinal(
            motivo = "Registrando entrada",
            maquina = maquina
        )

        println("[Slot ${slot.numero}] Registrando entrada de ${maquina.codigo}...")
        delay(3_000)

        when (val estadoActual = slot.estado) {
            is EstadoSlot.EnCicloFinal -> {
                if (estadoActual.maquina?.codigo != maquina.codigo) {
                    throw OperacionSlotException("el slot cambió de operación durante el registro de entrada.")
                }
                slot.estado = EstadoSlot.EnUso(maquina)
                println("[OK] ${maquina.codigo} asignada al slot ${slot.numero}.")
            }

            EstadoSlot.Libre -> throw OperacionSlotException("el slot quedó libre antes de confirmar la entrada.")
            is EstadoSlot.EnUso -> throw OperacionSlotException("el slot ya está ocupado por ${estadoActual.maquina.codigo}.")
            is EstadoSlot.FueraDeServicio -> throw OperacionSlotException("el slot está fuera de servicio: ${estadoActual.motivo}.")
        }
    }

    suspend fun registrarSalida(codigoIngresado: String, minutosUso: Int): Ticket {
        val codigo = Validador.validarCodigoMaquina(codigoIngresado)

        val slot = slots.firstOrNull {
            val estado = it.estado
            estado is EstadoSlot.EnUso && estado.maquina.codigo == codigo
        } ?: throw MaquinaNoEncontradaException(codigo)

        val maquina = when (val estadoActual = slot.estado) {
            is EstadoSlot.EnUso -> estadoActual.maquina
            EstadoSlot.Libre -> throw OperacionSlotException("se intentó retirar una máquina desde un slot libre.")
            is EstadoSlot.EnCicloFinal -> throw OperacionSlotException("el slot ya está procesando: ${estadoActual.motivo}.")
            is EstadoSlot.FueraDeServicio -> throw OperacionSlotException("el slot está fuera de servicio: ${estadoActual.motivo}.")
        }

        slot.estado = EstadoSlot.EnCicloFinal(
            motivo = "Calculando tarifa",
            maquina = maquina
        )

        println("[Slot ${slot.numero}] Calculando tarifa para ${maquina.codigo}...")
        delay(6_500)

        try {
            val montoFinal = calcularMontoFinal(maquina, minutosUso)

            val ticket = Ticket(
                numero = siguienteTicket++,
                tipoMaquina = maquina.tipo,
                codigoMaquina = maquina.codigo,
                minutosUso = minutosUso,
                montoPagado = montoFinal
            )

            historial += Atencion(maquina, ticket)
            recaudacionTotal += montoFinal
            recaudacionPorTipo[maquina.tipo] = recaudacionPorTipo.getValue(maquina.tipo) + montoFinal

            slot.estado = EstadoSlot.Libre

            println("[OK] Salida completada: ticket #${ticket.numero} - ${maquina.codigo} - ${formatearDinero(montoFinal)}")
            return ticket
        } catch (e: Exception) {
            // Si falla la tarifa, la máquina sigue ocupando el slot y el sistema puede continuar.
            slot.estado = EstadoSlot.EnUso(maquina)
            throw e
        }
    }

    private fun calcularMontoFinal(maquina: Maquina, minutosUso: Int): Double {
        val subtotal = maquina.calcularSubtotal(minutosUso)

        if (subtotal < 0 || (subtotal == 0.0 && !maquina.permiteMontoCero(minutosUso))) {
            throw TarifaInvalidaException("se obtuvo un subtotal no permitido para ${maquina.codigo}.")
        }

        // La Secadora < 30 min es un caso válido de monto cero.
        if (subtotal == 0.0 && maquina.permiteMontoCero(minutosUso)) {
            return 0.0
        }

        val montoConIva = subtotal * 1.19
        val montoFinal = if (maquina.tipoUsuario == TipoUsuario.EMPRESA) {
            montoConIva * 0.50
        } else {
            montoConIva
        }

        if (montoFinal <= 0) {
            throw TarifaInvalidaException("el monto final debe ser mayor que cero.")
        }

        return montoFinal
    }

    fun cantidadSlotsDisponibles(): Int =
        slots.count { it.estado is EstadoSlot.Libre }

    fun maquinasSuscriptorDelTurno(): List<Maquina> =
        historial
            .filter { it.maquina.tipoUsuario == TipoUsuario.SUSCRIPTOR }
            .map { it.maquina }

    fun ingresoPromedioPorMaquina(): Double =
        if (historial.isEmpty()) 0.0 else recaudacionTotal / historial.size

    fun codigosMaquinasFinalizadas(): List<String> =
        historial.map { it.maquina.codigo }

    fun maquinaConMayorTiempoDeUso(): Atencion? =
        historial.maxByOrNull { it.ticket.minutosUso }

    fun tipoMaquinaConMasIngresos(): TipoMaquina? =
        if (historial.isEmpty()) null else recaudacionPorTipo.maxByOrNull { it.value }?.key

    fun ponerSlotFueraDeServicio(numeroSlot: Int, motivo: String) {
        val slot = obtenerSlot(numeroSlot)

        when (val estado = slot.estado) {
            EstadoSlot.Libre -> slot.estado = EstadoSlot.FueraDeServicio(motivo)
            is EstadoSlot.EnUso -> throw OperacionSlotException(
                "el slot $numeroSlot está ocupado por ${estado.maquina.codigo}; no puede inhabilitarse ahora."
            )
            is EstadoSlot.EnCicloFinal -> throw OperacionSlotException(
                "el slot $numeroSlot está procesando '${estado.motivo}'."
            )
            is EstadoSlot.FueraDeServicio -> throw OperacionSlotException(
                "el slot $numeroSlot ya está fuera de servicio: ${estado.motivo}."
            )
        }
    }

    fun habilitarSlot(numeroSlot: Int) {
        val slot = obtenerSlot(numeroSlot)

        when (val estado = slot.estado) {
            is EstadoSlot.FueraDeServicio -> slot.estado = EstadoSlot.Libre
            EstadoSlot.Libre -> throw OperacionSlotException("el slot $numeroSlot ya se encuentra libre.")
            is EstadoSlot.EnUso -> throw OperacionSlotException("el slot $numeroSlot está actualmente en uso.")
            is EstadoSlot.EnCicloFinal -> throw OperacionSlotException("el slot $numeroSlot está procesando '${estado.motivo}'.")
        }
    }

    fun mostrarEstadoSlots() {
        println("\n===== ESTADO ACTUAL DE SLOTS =====")
        slots.forEach { slot ->
            val descripcion = when (val estado = slot.estado) {
                EstadoSlot.Libre -> "Libre"
                is EstadoSlot.EnUso -> "EnUso - ${estado.maquina.codigo}"
                is EstadoSlot.EnCicloFinal -> "EnCicloFinal - ${estado.motivo}"
                is EstadoSlot.FueraDeServicio -> "FueraDeServicio - ${estado.motivo}"
            }
            println("Slot ${slot.numero}: $descripcion")
        }
    }

    fun mostrarConsultasDeNegocio() {
        println("\n===== CONSULTAS DE NEGOCIO =====")
        println("Slots disponibles: ${cantidadSlotsDisponibles()}")

        val suscriptores = maquinasSuscriptorDelTurno()
        println(
            "Máquinas de clientes suscriptor: " +
                if (suscriptores.isEmpty()) "Ninguna" else suscriptores.joinToString { it.codigo }
        )

        println("Ingreso promedio por máquina: ${formatearDinero(ingresoPromedioPorMaquina())}")

        val finalizadas = codigosMaquinasFinalizadas()
        println("Códigos finalizados: ${if (finalizadas.isEmpty()) "Ninguno" else finalizadas.joinToString()}")

        val mayorUso = maquinaConMayorTiempoDeUso()
        println(
            "Mayor tiempo de uso: " +
                if (mayorUso == null) "Sin atenciones" else "${mayorUso.maquina.codigo} (${mayorUso.ticket.minutosUso} min)"
        )
    }

    fun mostrarReporteCierre() {
        println("\n====================================================")
        println("           REPORTE DE CIERRE - $nombre")
        println("====================================================")

        if (historial.isEmpty()) {
            println("No hubo máquinas atendidas durante el turno.")
        } else {
            historial.forEach { atencion ->
                val t = atencion.ticket
                println(
                    "Ticket #${t.numero} | ${t.tipoMaquina.nombreVisible} | ${t.codigoMaquina} | " +
                        "${t.minutosUso} min | ${formatearDinero(t.montoPagado)}"
                )
            }
        }

        println("----------------------------------------------------")
        println("Total recaudado: ${formatearDinero(recaudacionTotal)}")
        println("Máquinas atendidas: ${historial.size}")
        println("Ingreso promedio: ${formatearDinero(ingresoPromedioPorMaquina())}")
        println("Tipo con más ingresos: ${tipoMaquinaConMasIngresos()?.nombreVisible ?: "Sin datos"}")
        println("Slots disponibles al cierre: ${cantidadSlotsDisponibles()}")
        println("====================================================")
    }

    private fun estadoPermiteEntrada(estado: EstadoSlot): Boolean = when (estado) {
        EstadoSlot.Libre -> true
        is EstadoSlot.EnUso -> false
        is EstadoSlot.EnCicloFinal -> false
        is EstadoSlot.FueraDeServicio -> false
    }

    private fun obtenerSlot(numeroSlot: Int): Slot =
        slots.getOrNull(numeroSlot - 1)
            ?: throw OperacionSlotException("no existe el slot número $numeroSlot.")

    private fun formatearDinero(monto: Double): String {
        val formato = DecimalFormat("#,##0")
        return "$" + formato.format(monto).replace(',', '.')
    }
}
