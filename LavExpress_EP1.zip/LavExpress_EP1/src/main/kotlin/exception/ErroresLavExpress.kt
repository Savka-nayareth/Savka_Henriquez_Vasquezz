package exception

open class LavExpressException(message: String) : Exception(message)

class CodigoMaquinaInvalidoException(codigo: String) :
    LavExpressException("Código de máquina inválido: '$codigo'. Debe tener el formato AA00AA.")

class TarifaInvalidaException(detalle: String) :
    LavExpressException("Resultado de tarifa inválido: $detalle")

class MaquinaNoEncontradaException(codigo: String) :
    LavExpressException("Máquina no encontrada: no existe una máquina activa con código $codigo.")

class SinCapacidadException :
    LavExpressException("Sistema sin capacidad: no existen slots libres disponibles.")

class OperacionSlotException(detalle: String) :
    LavExpressException("No fue posible completar la operación del slot: $detalle")
