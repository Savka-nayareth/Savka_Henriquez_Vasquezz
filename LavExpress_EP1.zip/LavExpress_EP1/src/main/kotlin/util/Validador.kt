package util

import exception.CodigoMaquinaInvalidoException

object Validador {
    private val patronCodigo = Regex("^[A-Za-z]{2}\\d{2}[A-Za-z]{2}$")

    fun validarCodigoMaquina(codigo: String): String {
        val codigoNormalizado = codigo.trim().uppercase()
        if (!patronCodigo.matches(codigoNormalizado)) {
            throw CodigoMaquinaInvalidoException(codigo)
        }
        return codigoNormalizado
    }
}
