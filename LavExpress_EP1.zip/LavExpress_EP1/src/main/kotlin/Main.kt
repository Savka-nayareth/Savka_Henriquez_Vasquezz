import exception.LavExpressException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import model.*
import service.LavExpressService

fun main() = runBlocking {
    val sistema = LavExpressService()

    println("============================================")
    println("      ${sistema.nombre} - Inicio de turno")
    println("      Capacidad: ${sistema.capacidad} slots")
    println("============================================\n")

    // Prueba controlada de código inválido. El error se informa sin cerrar el sistema.
    ejecutarSeguro("Prueba de código inválido") {
        Lavadora("123ABC", "Marca", "Modelo", TipoUsuario.REGULAR)
    }

    val maquinas = listOf(
        Lavadora("LV12CD", "Samsung", "WW90", TipoUsuario.SUSCRIPTOR),
        Lavadora("LV99ZA", "LG", "F4WV509", TipoUsuario.REGULAR),
        Secadora("SC22TO", "Bosch", "WTH85200", TipoUsuario.REGULAR),
        LavasecaIndustrial("LI44RG", "Miele", "PW6", TipoUsuario.EMPRESA, conVapor = true),
        LavasecaIndustrial("LI77RG", "Speed Queen", "SF7", TipoUsuario.REGULAR, conVapor = false)
    )

    println("\n--- REGISTRO ASÍNCRONO DE ENTRADAS ---")
    coroutineScope {
        maquinas.map { maquina ->
            launch {
                ejecutarSeguro("Entrada ${maquina.codigo}") {
                    sistema.registrarEntrada(maquina)
                }
            }
        }.joinAll()
    }

    sistema.mostrarEstadoSlots()

    println("\n--- REGISTRO ASÍNCRONO DE SALIDAS ---")
    val salidas = listOf(
        "LV12CD" to 75,
        "LV99ZA" to 180,
        "SC22TO" to 25,
        "LI44RG" to 120,
        "LI77RG" to 45
    )

    coroutineScope {
        salidas.map { (codigo, minutos) ->
            launch {
                ejecutarSeguro("Salida $codigo") {
                    sistema.registrarSalida(codigo, minutos)
                }
            }
        }.joinAll()
    }

    // Error solicitado por R6: máquina inexistente. Debe continuar normalmente.
    ejecutarSeguro("Máquina no encontrada") {
        sistema.registrarSalida("AA11BB", 60)
    }

    sistema.mostrarEstadoSlots()
    sistema.mostrarConsultasDeNegocio()
    sistema.mostrarReporteCierre()
}

/**
 * Centraliza el manejo de errores esperables para que una falla de datos no termine
 * abruptamente la ejecución ni muestre trazas técnicas al usuario.
 */
suspend fun <T> ejecutarSeguro(nombreOperacion: String, bloque: suspend () -> T): T? {
    return try {
        bloque()
    } catch (e: LavExpressException) {
        println("[ERROR] $nombreOperacion: ${e.message}")
        null
    } catch (e: Exception) {
        println("[ERROR] $nombreOperacion: ocurrió un problema inesperado, pero el sistema seguirá operativo.")
        null
    }
}
