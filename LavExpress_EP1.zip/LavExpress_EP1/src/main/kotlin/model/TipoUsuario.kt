package model

import exception.LavExpressException

enum class TipoUsuario {
    REGULAR,
    SUSCRIPTOR,
    EMPRESA;

    companion object {
        fun desdeTexto(valor: String): TipoUsuario = when (valor.trim().lowercase()) {
            "regular" -> REGULAR
            "suscriptor" -> SUSCRIPTOR
            "empresa" -> EMPRESA
            else -> throw LavExpressException(
                "Tipo de usuario inválido: '$valor'. Valores permitidos: regular, suscriptor o empresa."
            )
        }
    }
}
