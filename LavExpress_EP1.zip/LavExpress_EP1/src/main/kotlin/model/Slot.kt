package model

class Slot(
    val numero: Int,
    var estado: EstadoSlot = EstadoSlot.Libre
)
