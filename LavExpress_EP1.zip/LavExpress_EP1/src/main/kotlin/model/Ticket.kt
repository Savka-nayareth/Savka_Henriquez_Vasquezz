package model

import java.time.LocalDateTime

data class Ticket(
    val numero: Int,
    val tipoMaquina: TipoMaquina,
    val codigoMaquina: String,
    val minutosUso: Int,
    val montoPagado: Double,
    val fechaEmision: LocalDateTime = LocalDateTime.now()
)
