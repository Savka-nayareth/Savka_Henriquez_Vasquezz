package model

class Secadora(
    codigo: String,
    marca: String,
    modelo: String,
    tipoUsuario: TipoUsuario
) : Maquina(codigo, marca, modelo, tipoUsuario) {

    override val tipo = TipoMaquina.SECADORA
    override val tarifaHora = 1000.0

    override fun calcularSubtotal(minutosUso: Int): Double {
        // Regla especial: menos de 30 minutos no genera cobro.
        if (minutosUso <= 0) {
            return calcularPorTiempo(minutosUso)
        }
        if (minutosUso < 30) return 0.0

        val valorTiempo = calcularPorTiempo(minutosUso)
        return aplicarBeneficioSuscriptor(valorTiempo)
    }

    override fun permiteMontoCero(minutosUso: Int): Boolean = minutosUso in 1..29
}
