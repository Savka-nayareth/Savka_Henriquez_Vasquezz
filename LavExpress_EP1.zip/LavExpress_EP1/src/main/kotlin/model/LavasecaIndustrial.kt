package model

class LavasecaIndustrial(
    codigo: String,
    marca: String,
    modelo: String,
    tipoUsuario: TipoUsuario,
    val conVapor: Boolean
) : Maquina(codigo, marca, modelo, tipoUsuario) {

    override val tipo = TipoMaquina.LAVASECA_INDUSTRIAL
    override val tarifaHora = 2800.0

    override fun calcularSubtotal(minutosUso: Int): Double {
        var subtotal = calcularPorTiempo(minutosUso)

        if (conVapor) {
            subtotal *= 1.30
        }

        return aplicarBeneficioSuscriptor(subtotal)
    }

    override fun detalle(): String =
        super.detalle() + " | vapor: ${if (conVapor) "sí" else "no"}"
}
