package model

sealed class EstadoSlot {
    data object Libre : EstadoSlot()

    data class EnUso(
        val maquina: Maquina
    ) : EstadoSlot()

    data class EnCicloFinal(
        val motivo: String,
        val maquina: Maquina? = null
    ) : EstadoSlot()

    data class FueraDeServicio(
        val motivo: String
    ) : EstadoSlot()
}
