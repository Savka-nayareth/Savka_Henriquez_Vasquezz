package model

class Lavadora(
    codigo: String,
    marca: String,
    modelo: String,
    tipoUsuario: TipoUsuario
) : Maquina(codigo, marca, modelo, tipoUsuario) {

    override val tipo = TipoMaquina.LAVADORA
    override val tarifaHora = 1200.0

    override fun calcularSubtotal(minutosUso: Int): Double {
        val valorTiempo = calcularPorTiempo(minutosUso)
        return aplicarBeneficioSuscriptor(valorTiempo)
    }
}
