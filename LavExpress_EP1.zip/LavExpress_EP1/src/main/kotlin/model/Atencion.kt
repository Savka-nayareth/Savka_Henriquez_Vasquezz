package model

data class Atencion(
    val maquina: Maquina,
    val ticket: Ticket
)
