package model

import exception.TarifaInvalidaException
import util.Validador
import java.time.LocalDateTime

abstract class Maquina(
    codigo: String,
    val marca: String,
    val modelo: String,
    val tipoUsuario: TipoUsuario
) {
    val codigo: String = Validador.validarCodigoMaquina(codigo)
    val fechaIngreso: LocalDateTime = LocalDateTime.now()

    abstract val tipo: TipoMaquina
    protected abstract val tarifaHora: Double

    /**
     * Calcula el valor antes de IVA y antes del descuento corporativo de empresa.
     * Cada subtipo agrega aquí sus reglas particulares de negocio.
     */
    abstract fun calcularSubtotal(minutosUso: Int): Double

    /** Permite diferenciar el $0 válido de Secadora < 30 min de un $0 erróneo. */
    open fun permiteMontoCero(minutosUso: Int): Boolean = false

    protected fun calcularPorTiempo(minutosUso: Int): Double {
        if (minutosUso <= 0) {
            throw TarifaInvalidaException("el tiempo de uso debe ser mayor que cero minutos.")
        }
        return tarifaHora * minutosUso / 60.0
    }

    protected fun aplicarBeneficioSuscriptor(monto: Double): Double =
        if (tipoUsuario == TipoUsuario.SUSCRIPTOR) monto * 0.80 else monto

    open fun detalle(): String =
        "${tipo.nombreVisible} | $codigo | $marca $modelo | usuario: ${tipoUsuario.name.lowercase()}"
}
