package model

enum class TipoMaquina(val nombreVisible: String) {
    LAVADORA("Lavadora"),
    SECADORA("Secadora"),
    LAVASECA_INDUSTRIAL("LavasecaIndustrial")
}
